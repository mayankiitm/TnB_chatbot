# This is the Multilingual QNA bot
## You have to give input of Language as X(other language) and any topic. And then ask questions about that topic. 
## The bot will return answers in X and English.

![img_1.png](img_1.png)