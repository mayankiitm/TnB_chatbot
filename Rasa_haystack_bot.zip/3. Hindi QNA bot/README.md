# This is the Hindi QNA bot
## You have to give input of Language as Hindi and any topic. And then ask questions about that topic. 
## The bot will return answers in hindi and English.

![img.png](img.png)