# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List
import requests
from trans import translate
import time
from rasa_sdk.events import SlotSet, EventType

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher


class ValidateDocDetailForm(Action):
    def name(self) -> Text:
        return "doc_details_form"

    def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["gender", "clothing", "material", "size", "colour"]

        for slot_name in required_slots:
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]

        # All slots are filled.
        return [SlotSet("requested_slot", None)]


class ActionAddLink(Action):

    def name(self) -> Text:
        return "add_link"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        dispatcher.utter_message(text="Please wait...")
        t = time.time_ns()
        lang_code = {"english": "en", "hindi": "hi", "indonesian": "id", "french": "fr", "german": "de", "tamil": "t"}
        lang = str(tracker.get_slot("lang")).lower()
        lang = lang_code[lang]
        payload = {"link": str(tracker.get_slot("link")), "lang": lang}

        url = "http://ec2-54-213-65-10.us-west-2.compute.amazonaws.com:8080/link?link="+payload['link']+"&lang="+payload['lang']
        response = requests.request("POST", url, json=payload).json()
        print(response)
        if response["status"] == "Data Added from Wikipedia":
            status = response["status"]+". Now you can ask your question:)"
        else:
            status = response["status"]
        rt = time.time_ns()
        at = rt - t
        print('total time taken', round(at * 1e-9, 3), 'seconds')
        dispatcher.utter_message(text=status)

        # dispatcher.utter_message(text="No Page Found!!")

        return []


class ActionHaystack(Action):

    def name(self) -> Text:
        return "call_haystack"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        t = time.time_ns()

        payload = {"query": str(tracker.latest_message["text"])}
        url = "http://ec2-54-213-65-10.us-west-2.compute.amazonaws.com:8080/answer?question="+payload['query']
        headers = {
            'Content-Type': 'application/json'
        }
        response = requests.request("POST", url, headers=headers, json=payload).json()

        if str(tracker.get_slot("lang")).lower() == "hindi":
            if response["answers"]:
                answer = '-> Answer:' + response["answers"][0]["answer"] + '\n -> Context:' + response["answers"][0]["context"]
                context = str(response["answers"][0]["context"])
                doc = response["answers"][0]["meta"]["name"]
                context = context.replace("\n", "")
                context = translate(context)
                ans = str(response["answers"][0]["answer"])
                ans = ans.replace("\n", "")
                ans = translate(ans)

                trans = '-> Answer:' + ans + '\n-> Context:' + context
                rt = time.time_ns()
                at = rt - t
                print('total time taken', round(at * 1e-9, 3), 'seconds')
                document = "Referenced Doc:" + str(doc)
                dispatcher.utter_message(text=answer)
                dispatcher.utter_message(text="Here is the Translation in English")
                dispatcher.utter_message(text=trans)
                dispatcher.utter_message(text=document)
            else:
                answer = "No Answer Found!"
                dispatcher.utter_message(text=answer)
        else:
            if response["answers"]:
                res_ans = response["answers"][0]["answer"].encode('raw-unicode-escape').decode('utf-8')
                res_con = response["answers"][0]["context"].encode('raw-unicode-escape').decode('utf-8')
                answer = '-> Answer:' + res_ans + '\n -> Context:' + res_con
                context = str(res_con)
                doc = response["answers"][0]["meta"]["name"]
                context = context.replace("\n", "")
                context = translate(context)
                ans = str(res_ans)
                ans = ans.replace("\n", "")
                ans = translate(ans)

                trans = '-> Answer:' + ans + '\n-> Context:' + context
                rt = time.time_ns()
                at = rt - t
                print('total time taken', round(at * 1e-9, 3), 'seconds')
                document = "Referenced Doc:" + str(doc)
                dispatcher.utter_message(text=answer)
                dispatcher.utter_message(text="Here is the Translation in English")
                dispatcher.utter_message(text=trans)
                dispatcher.utter_message(text=document)
            else:
                answer = "No Answer Found!"
                dispatcher.utter_message(text=answer)
        return []
