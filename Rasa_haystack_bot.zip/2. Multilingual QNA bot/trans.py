from googletrans import Translator


def translate(text) -> object:
    trans = Translator(service_urls=['translate.googleapis.com'])
    res = trans.translate(text, dest="en")

    return res.text


# from deep_translator import GoogleTranslator
# translated = GoogleTranslator(source='auto', target='de').translate("keep it up, you are awesome")
# t = "l lainnya, Instagram menjadi sebuah media untuk memberitahukan suatu kegiatan sosial dalam cakupan lokal ataupun mancanegara. Cara yang digunakan untu"
# print(translate(t))
# import wikipedia
#
# # setting language to hindi
# from wikipedia import PageError
#
# wikipedia.set_lang("id")
#
# # printing the summary
# try:
#     print(wikipedia.page("spiderman"))
# except PageError:
#     print("No Page")