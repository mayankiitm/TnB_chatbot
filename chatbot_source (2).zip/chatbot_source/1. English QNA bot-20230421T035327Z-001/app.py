from flask import Flask, request, redirect, url_for, flash, jsonify
import requests
from bs4 import BeautifulSoup
import json
from haystack.nodes import PreProcessor
from haystack.pipelines import ExtractiveQAPipeline
from haystack.nodes import TfidfRetriever
from haystack.utils import clean_wiki_text, convert_files_to_dicts, print_answers
from haystack.nodes import FARMReader
from haystack.document_stores import InMemoryDocumentStore
import warnings

warnings.filterwarnings("ignore")

app = Flask(__name__)
document_store = InMemoryDocumentStore()
all_docs = convert_files_to_dicts(dir_path="data")

preprocessor = PreProcessor(
    clean_empty_lines=True,
    clean_whitespace=True,
    clean_header_footer=False,
    split_by="word",
    split_length=100,
    split_respect_sentence_boundary=True
)
docs = preprocessor.process(all_docs)

document_store.write_documents(docs)

retriever = TfidfRetriever(document_store=document_store)

reader = FARMReader(model_name_or_path="distilbert-base-uncased-distilled-squad", use_gpu=True)


@app.route('/link', methods=['GET', 'POST'])
def getlink():
    link = request.args['link']
    file = open("data/research.txt", 'w')
    req = requests.get(link)
    soup = BeautifulSoup(req.content, 'html.parser')
    text = ''
    for paragraph in soup.find_all('p'):
        text += paragraph.text

    file.write(text)
    status = "Text Added"
    all_docs = convert_files_to_dicts(dir_path="data")

    preprocessor = PreProcessor(
        clean_empty_lines=True,
        clean_whitespace=True,
        clean_header_footer=False,
        split_by="word",
        split_length=100,
        split_respect_sentence_boundary=True
    )
    docs = preprocessor.process(all_docs)
    document_store.write_documents(docs)
    
    status += "|| Process Completed"
    file.close()
    return status


@app.route('/answer', methods=['GET', 'POST'])
def getans():
    question = request.args['question']
    retriever = TfidfRetriever(document_store=document_store)
    pipe = ExtractiveQAPipeline(reader, retriever)
    prediction = pipe.run(query=question, params={"Retriever": {"top_k": 2}, "Reader": {"top_k": 2}})
    f = open("data/research.txt", 'w') 
    f.seek(0)  # sets  point at the beginning of the file
    f.truncate()  # Clear previous content
    f.close()
    return prediction


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)