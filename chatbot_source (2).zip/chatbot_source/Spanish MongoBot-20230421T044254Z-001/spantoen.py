from flask import Flask, request
from flask_cors import CORS
from googletrans import Translator

app = Flask(__name__)
CORS(app)


@app.route('/trans', methods=['GET', 'POST'])
def trans():
    text1 = request.args['text']
    lang = request.args['lang']
    print(lang)
    translator = Translator(service_urls=['translate.googleapis.com'])
    res = translator.translate(text1, dest=lang)
    # ans = {"status": res.text}
    return res.text


if __name__ == '__main__':
    app.run(debug=False, host='localhost', port=8989)
