from flask import Flask, request
import wikipedia
from wikipedia import PageError
from haystack.nodes import PreProcessor
from haystack.pipelines import ExtractiveQAPipeline
from haystack.nodes import TfidfRetriever
from haystack.utils import convert_files_to_dicts
from haystack.nodes import FARMReader
from haystack.document_stores import InMemoryDocumentStore
import warnings

warnings.filterwarnings("ignore")

app = Flask(__name__)
document_store = InMemoryDocumentStore()
all_docs = convert_files_to_dicts(dir_path="data1")

preprocessor = PreProcessor(
    clean_empty_lines=True,
    clean_whitespace=True,
    clean_header_footer=False,
    split_by="word",
    split_length=100,
    split_respect_sentence_boundary=True
)
docs = preprocessor.process(all_docs)

document_store.write_documents(docs)

retriever = TfidfRetriever(document_store=document_store)

reader = FARMReader(model_name_or_path="deepset/xlm-roberta-base-squad2")


@app.route('/link', methods=['GET', 'POST'])
def getlink():
    link = request.args['link']
    lang = request.args['lang']
    file = open("data1/research.txt", 'w')
    try:
        wikipedia.set_lang(lang)
        text = wikipedia.page(link).content
        file.write(text)
        all_docs = convert_files_to_dicts(dir_path="data1")

        preprocessor = PreProcessor(
            clean_empty_lines=True,
            clean_whitespace=True,
            clean_header_footer=False,
            split_by="word",
            split_length=100,
            split_respect_sentence_boundary=True
        )
        docs = preprocessor.process(all_docs)
        document_store.write_documents(docs)
        retriever = TfidfRetriever(document_store=document_store)

        ans = {"status": "Data Added from Wikipedia"}
        return ans
    except PageError:
        ans = {"status": "No page found!"}
        return ans


@app.route('/answer', methods=['GET', 'POST'])
def getans():
    question = request.args['question']
    # lang = request.args['lang']
    # question = GoogleTranslator(source='auto', target=lang).translate(question)
    pipe = ExtractiveQAPipeline(reader, retriever)
    prediction = pipe.run(query=question, params={"Retriever": {"top_k": 2}, "Reader": {"top_k": 2}})

    file = open("data1/research.txt", 'w')
    file.seek(0)
    file.truncate()
    file.close()

    return prediction


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
