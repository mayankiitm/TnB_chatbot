from flask import Flask, request, jsonify
import json
import wikipedia
from wikipedia import PageError
from deep_translator import GoogleTranslator
from haystack.nodes import PDFToTextConverter
from haystack.pipelines import ExtractiveQAPipeline
from haystack.nodes import TfidfRetriever
from haystack.utils import clean_wiki_text, convert_files_to_dicts
from haystack.nodes import FARMReader
from haystack.document_stores import InMemoryDocumentStore
import warnings

warnings.filterwarnings("ignore")

app = Flask(__name__)
document_store = InMemoryDocumentStore()
docs = convert_files_to_dicts(dir_path="data1")
document_store.write_documents(docs)
print(document_store)
retriever = TfidfRetriever(document_store=document_store)

reader = FARMReader(model_name_or_path="bhavikardeshna/xlm-roberta-base-hindi")


@app.route('/link', methods=['GET', 'POST'])
def getlink():
    link = request.args['link']
    lang = request.args['lang']
    file = open("data1/research.txt", 'w')
    try:
        wikipedia.set_lang(lang)
        text = wikipedia.page(link).content
        file.write(text)
        docs = convert_files_to_dicts(dir_path="data1")
        document_store.write_documents(docs)
        retriever = TfidfRetriever(document_store=document_store)

        ans = {"status": "Data Added from Wikipedia"}
        return ans
    except PageError:
        ans = {"status": "Page not found!"}
        return ans



@app.route('/answer', methods=['GET', 'POST'])
def getans():
    question = request.args['question']
    #lang = request.args['lang']
    #question = GoogleTranslator(source='auto', target=lang).translate(question)
    pipe = ExtractiveQAPipeline(reader, retriever)
    prediction = pipe.run(query=question, params={"Retriever": {"top_k": 2}, "Reader": {"top_k": 2}})
    
    file = open("data1/research.txt", 'w')
    file.seek(0)
    file.truncate()
    file.close()
    
    return prediction

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
