# This is the English QNA bot.
## You have to give input of Language as English and any topic. And then ask questions about that topic. 
## Also, there is already a fed document, so You can directly ask questions about that as well.
## The bot will return answers in English.

![img_2.png](img_2.png)
# Already fed document about corona virus
![img_3.png](img_3.png)