# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List
import requests
import time
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher


class ActionHelloWorld(Action):

    def name(self) -> Text:
        return "action_hello_world"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        dispatcher.utter_message(text="Hello World!")

        return []


class ActionAddLink(Action):

    def name(self) -> Text:
        return "add_link"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        t = time.time_ns()
        payload = {"link": str(tracker.latest_message["text"])}
        url = "http://ec2-34-222-131-128.us-west-2.compute.amazonaws.com:8080/link?link="+payload['link']
        headers = {'Content-Type': 'application/json'}
        response = requests.request("POST", url, headers=headers, json=payload)
        print(response)
        rt = time.time_ns()
        at = rt - t
        print('total time taken', round(at * 1e-9, 3), 'seconds')
        dispatcher.utter_message(text="Now you can ask your question:)")

        return []


class ActionHaystack(Action):

    def name(self) -> Text:
        return "call_haystack"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        t = time.time_ns()
        payload = {"query": str(tracker.latest_message["text"])}
        url = "http://ec2-34-222-131-128.us-west-2.compute.amazonaws.com:8080/answer?question="+payload['query']
        headers = {
            'Content-Type': 'application/json'
        }
        response = requests.request("POST", url, headers=headers, json=payload).json()
        if response["answers"]:
            answer = '-> Answer:' + response["answers"][0]["answer"] + '\n-> Context:' + response["answers"][0]["context"]
        else:
            answer = "No Answer Found!"
        rt = time.time_ns()
        at = rt - t
        print('total time taken', round(at * 1e-9, 3), 'seconds')
        dispatcher.utter_message(text=answer)

        return []
